package e_stub_solution;

public class ThermometerStub implements Thermometer {

  @Override
  public double readTemperature() {
    return 2;
  }
}
