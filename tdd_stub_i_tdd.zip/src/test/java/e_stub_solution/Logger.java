package e_stub_solution;

public interface Logger {
  public void log(String message);
}
