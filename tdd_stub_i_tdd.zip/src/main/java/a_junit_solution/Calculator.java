package a_junit_solution;

public class Calculator {

  public Integer add(Integer a, Integer b) {
    return a + b;
  }

  public Integer substract(Integer a, Integer b) {
    return a - b;
  }

  public Integer multiply(Integer a, Integer b) {
    return a * b;
  }

  public Integer divide(Integer a, Integer b) {
    return a / b;
  }

}
