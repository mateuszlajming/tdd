# Zadanie

 1. Utwórz klasę z testami o nazwie `AssertJCalculatorTest`.
 1. W tej klasie napisz testy dla metody `divide` klasy `ExceptionsCalculator` wykorzystując asercje z biblioteki AssertJ:
     * standardowe dzielenie
     * sytuacja gdy rzucany jest wyjątek
     
# Zadanie

 1. Utwórz klasę z testami `ZooTest`.
 1. Napisz testy dla klasy `Zoo`. Wykorzystaj bibliotekę AssertJ.
 
Przypadki testowe:
* Zoo zaraz po utworzeniu jest puste
* Po dodaniu jednego zwierzątka w Zoo jest tylko jedno, konkretne zwierzątko
* Przetestuj też pozostałe metody klasy Zoo

