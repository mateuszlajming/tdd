package f_mockito;

import java.util.List;

public interface Database {
  List<Book> getBooks();
}