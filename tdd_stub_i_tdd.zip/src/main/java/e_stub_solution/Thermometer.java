package e_stub_solution;

public interface Thermometer {

  public double readTemperature();

}