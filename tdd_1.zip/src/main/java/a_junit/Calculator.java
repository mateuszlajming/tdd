package a_junit;

public class Calculator {

  public Integer add(Integer a, Integer b) {
    return a + b;
  }

}
