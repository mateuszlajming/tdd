# Zadanie

 1. Utwórz klasę `ExceptionsCalculator`.
 1. Skopiuj metody `add`, `substract`, `multiply` i `divide` z klasy `Calculator` z poprzedniego ćwiczenia.
 1. Zmodyfikuj te metody tak, aby jeśli, któryś z argumentów ma wartość `null` rzucany był wyjątek `IllegalArgumentException` z odpowiednią wiadomością.
 1. Dodatkowo jeśli przy dzieleniu dzielnik jest równy `0` również powinien być rzucany wyjątek z odpowiednią wiadomością.
 1. Następnie w odpowiednim miejscu utwórz klasę z testami.
 1. Pisząc testy użyj wszystkich trzech poznanych sposobów na testowanie wyjątków.