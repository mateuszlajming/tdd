# Zadanie

 1. Utwórz klasę z testami `BooksProcessorTest`.
 1. Przetestuj metody klasy `BooksProcessor`. Rozważ różne przypadki testowe.
 1. Przy tworzeniu obiektu typu `BooksProcessor` pamiętaj o wstrzyknięciu  atrapy obiektu typu `Database`. 
 Na początku użyj standardowego sposobu tworzenia mocków.
 1. Kiedy skończysz zmień kod w taki sposób aby wykorzystywał adnotacje `@Mock` i `@InjectMocks`.
