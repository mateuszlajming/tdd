package f_mockito;

public class BooksProcessorException extends RuntimeException {
  BooksProcessorException(String message, Throwable cause) {
    super(message, cause);
  }
}
