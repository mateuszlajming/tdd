# Zadanie

 1. Utwórz klasę z testami o nazwie `ParametrizedJUnitConstructorCalculatorTest`.
 1. W tej klasie przetestuj stworzoną wcześniej klasę `Calculator` wykorzystując JUnit i testy parametryzowane przez konstruktor.
 1. Następnie utwórz klasę z testami o nazwie `ParametrizedJUnitFieldsCalculatorTest`.
 1. W tej klasie przetestuj stworzoną wcześniej klasę `Calculator` wykorzystując JUnit i testy parametryzowane przez pola.
 1. Następnie utwórz klasę z testami o nazwie `ParametrizedJUnitParamsCalculatorTest`.
 1. W tej klasie przetestuj stworzoną wcześniej klasę `Calculator` wykorzystując JUnitParams.