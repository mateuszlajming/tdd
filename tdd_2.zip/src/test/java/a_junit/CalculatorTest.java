package a_junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculatorTest {

  @Test
  public void add_2Plus2_shouldReturn4() {
    // Arrange
    Calculator calculator = new Calculator();

    // Act
    Integer sum = calculator.add(2, 2);

    // Assert
    Integer expected = 4;
    assertEquals(expected, sum);
  }

}
