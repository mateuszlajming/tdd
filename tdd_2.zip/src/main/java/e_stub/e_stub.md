# Zadanie

 1. Utwórz klasę o nazwie `ThermometerStub`, która będzie atrapą termometru.
 Powinniśmy móc wpływać na to jaka temperatura jest zwracana przez atrapę.
 1. Zmodyfikuj klasę `TemperatureReader` tak aby przyjmowała termometr w konstruktorze (dependency injection).
 1. Utwórz klasę z testami o nazwie `TemperatureReaderTest`.
 1. W tej klasie dodaj testy klasy `TemperatureReader`.
 
 
# Zadanie

 1. W utworzonej wcześniej klasie `TemperatureReaderTest` dodaj test, w którym do 
  utworzenia atrapy użyjesz biblioteki Mockito.