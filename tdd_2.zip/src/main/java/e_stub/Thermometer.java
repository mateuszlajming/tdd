package e_stub;

public interface Thermometer {

  public double readTemperature();

}